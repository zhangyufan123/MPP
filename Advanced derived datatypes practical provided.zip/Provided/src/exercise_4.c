/**
 * @file exercise_4.c
 * @author Ludovic Capelli (l.capelli@epcc.ed.ac.uk)
 * @brief This application contains a simple 2-process configuration where one
 * MPI process sends an array of struct to the other one. However, the recipient
 * does not receive it as an array of structs, but as a struct of arrays.
 * @param argc The number of arguments received.
 * @param argv The values of the arguments received, with argv[0] being the
 * string containing the invocation command you typed to execute the program
 * (e.g.: mpirun -n 2 ./bin/main).
 * @return The error code indicating the exit status of the program. It is
 * common understanding that 0 represents a successful execution, while negative
 * values represent erroneous executions.
 * @pre The application is run using 2 MPI processes.
 **/

#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include "../include/exercise_4.h"

#define AOS_MEMBER_COUNT 3

void EPCC_create_MPI_datatypes(void)
{
    EPCC_printf("You need to implement this function.\n");
    MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
}

int main(int argc, char* argv[])
{
    // The number of MPI processes that this application must spawn.
    const int COMM_SIZE_EXPECTED = 2;

    MPI_Init(&argc, &argv);

    int comm_size;
    MPI_Comm_size(EPCC_DEFAULT_COMMUNICATOR, &comm_size);
    if(comm_size != COMM_SIZE_EXPECTED)
    {
        EPCC_printf("This application is meant to be run with %d MPI processes, not %d.\n", COMM_SIZE_EXPECTED, comm_size);
    }
    else
    {
        EPCC_create_MPI_datatypes();
        int my_rank;
        MPI_Comm_rank(EPCC_DEFAULT_COMMUNICATOR, &my_rank);
        switch(my_rank)
        {
            case SENDER:
            {
                struct AoS my_aos_variable[EPCC_ARRAY_SIZE];
                for(int i = 0; i < EPCC_ARRAY_SIZE; i++)
                {
                    my_aos_variable[i].d1 = (double)(i * 4);
                    my_aos_variable[i].i = i * 15;
                    my_aos_variable[i].d2 = (double)(i * 2 + 100);
                }
                EPCC_printf("To send:\n");
                for(int i = 0; i < EPCC_ARRAY_SIZE; i++)
                {
                    EPCC_printf("  - aos[%d] = %.1f, aos[%d].i = %d, aos[%d].d2 = %.1f\n", i, my_aos_variable[i].d1, i, my_aos_variable[i].i, i, my_aos_variable[i].d2);
                }
                MPI_Send(my_aos_variable, EPCC_ARRAY_SIZE, EPCC_MPI_AOS, RECEIVER, 0, EPCC_DEFAULT_COMMUNICATOR);
                break;
            }
            case RECEIVER:
            {
                struct SoA my_soa_variable;
                MPI_Recv(&my_soa_variable, 1, EPCC_MPI_SOA, SENDER, MPI_ANY_TAG, EPCC_DEFAULT_COMMUNICATOR, MPI_STATUS_IGNORE);
                EPCC_printf("Received:\n");
                for(int i = 0; i < EPCC_ARRAY_SIZE; i++)
                {
                    EPCC_printf("  - soa.d1[%d] = %.1f, soa.i[%d] = %d, soa.d2[%d] = %.1f\n", i, my_soa_variable.d1[i], i, my_soa_variable.i[i], i, my_soa_variable.d2[i]);
                }
                break;
            }
            default:
            {
                EPCC_printf("This line is not supposed to be reached. This program contains a bug.");
                MPI_Abort(EPCC_DEFAULT_COMMUNICATOR, EXIT_FAILURE);
                break;
            }
        }
    }

    MPI_Finalize();
    return EXIT_SUCCESS;
}
