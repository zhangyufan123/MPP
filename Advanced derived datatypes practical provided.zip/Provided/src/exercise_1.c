/**
 * @file exercise_1.c
 * @author Ludovic Capelli (l.capelli@epcc.ed.ac.uk)
 * @brief This application contains a 4-process scatter where the root MPI
 * process sends non-contiguous data to all MPI processes. In this instance,
 * columns of an 2-dimensional array.
 * MPI process sends a struct to the other one.
 * @param argc The number of arguments received.
 * @param argv The values of the arguments received, with argv[0] being the
 * string containing the invocation command you typed to execute the program
 * (e.g.: mpirun -n 4 ./bin/main).
 * @return The error code indicating the exit status of the program. It is
 * common understanding that 0 represents a successful execution, while negative
 * values represent erroneous executions.
 * @pre The application is run using 4 MPI processes.
 **/

#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>
#include "../include/exercise_1.h"

// Note: "number of rows" is equivalent to "length of a column"
#define EPCC_ROW_COUNT 5
// Note: "number of columns" is equivalent to "length of a row"
#define EPCC_COLUMN_COUNT 4

void EPCC_create_MPI_datatype(int row_count, int column_count)
{
    // Silences "row_count not used" warning until you actually use it.
    (void)row_count;
    // Silences "column_count not used" warning until you actually use it.
    (void)column_count;
    EPCC_printf("You have to implement the function %s.\n", __FUNCTION__);
    MPI_Abort(MPI_COMM_WORLD, EXIT_FAILURE);
}

int main(int argc, char* argv[])
{
    // The number of MPI processes that this application must spawn.
    const int COMM_SIZE_EXPECTED = 4;
    // The rank of the MPI process that will hold the array and issue the MPI_Scatter as the root.
    const int ROOT_MPI_PROCESS_RANK = 0;

    MPI_Init(&argc, &argv);

    int comm_size;
    MPI_Comm_size(EPCC_DEFAULT_COMMUNICATOR, &comm_size);
    if(comm_size != COMM_SIZE_EXPECTED)
    {
        EPCC_printf("This application is meant to be run with %d MPI processes, not %d.\n", COMM_SIZE_EXPECTED, comm_size);
    }
    else
    {
        int my_rank;
        MPI_Comm_rank(EPCC_DEFAULT_COMMUNICATOR, &my_rank);

        int column[EPCC_ROW_COUNT];
        EPCC_create_MPI_datatype(EPCC_ROW_COUNT, EPCC_COLUMN_COUNT);
        if(my_rank == ROOT_MPI_PROCESS_RANK)
        {
            /* Note: you would not initialise a 2-dimensional array this way
            normally. However, for educational purposes, doing it this way makes
            its memory layout more visible. */
            int buffer[EPCC_ROW_COUNT][EPCC_COLUMN_COUNT] = {{ 0,  1,  2,  3},
                                                   { 4,  5,  6,  7},
                                                   { 8,  9, 10, 11},
                                                   {12, 13, 14, 15},
                                                   {16, 17, 18, 19}};
            MPI_Scatter(buffer, 1, EPCC_MPI_COLUMN, column, EPCC_ROW_COUNT, MPI_INT, ROOT_MPI_PROCESS_RANK, EPCC_DEFAULT_COMMUNICATOR);
        }
        else
        {
            MPI_Scatter(NULL, 1, EPCC_MPI_COLUMN, column, EPCC_ROW_COUNT, MPI_INT, ROOT_MPI_PROCESS_RANK, EPCC_DEFAULT_COMMUNICATOR);
        }
        for(int i = 0; i < comm_size; i++)
        {
            if(my_rank == i)
            {
                EPCC_printf("The column I received contains elements: ");
                for(int j = 0; j < EPCC_ROW_COUNT; j++)
                {
                    printf("%d ", column[j]);
                }
                printf("\n");
            }
            MPI_Barrier(EPCC_DEFAULT_COMMUNICATOR);
        }
    }

    MPI_Finalize();
    return EXIT_SUCCESS;
}
